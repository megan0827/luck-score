__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root-of-the-server]__ec07ee34._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_a51498a5._.js",
  "static/chunks/[root-of-the-server]__f5f356b3._.js",
  "static/chunks/src_pages__app_5771e187._.js",
  "static/chunks/src_pages__app_36b782a6._.js"
])
