import Link from "next/link";
import Image from "next/image";

export default function HomePage() {
  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h1>Believe it or not Today's Luck Score!</h1>
      <p>믿거나 말거나 오늘의 운세 점수!</p>

      {/* 이미지 */}
      <div style={{ marginTop: "2rem", display: "flex", justifyContent: "center" }}>
        <Image
          src="/images/IMG_9735.jpg"
          alt="오늘의 운세 이미지"
          width={300}
          height={200}
        />
      </div>

      {/* 버튼들 */}
      <div style={{ marginTop: "2rem" }}>
        <Link href="/create">
          <button style={buttonStyle}>오늘의 운세 확인하기</button>
        </Link>

        <br />

        <Link href="/result">
          <button style={{ ...buttonStyle, marginTop: "1rem" }}>
            모든 결과 확인하기
          </button>
        </Link>

        <br />

        {/* 여기 About 페이지 이동 버튼 추가 */}
        <Link href="/about">
          <button style={{ ...buttonStyle, marginTop: "1rem" }}>
            소개 페이지
          </button>
        </Link>
      </div>
    </div>
  );
}

const buttonStyle = {
  padding: "0.5rem 1rem",
  backgroundColor: "#4F46E5",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
};

