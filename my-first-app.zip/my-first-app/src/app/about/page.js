export default function AboutPage() {
   return (
     <div style={{ padding: "2rem", textAlign: "center" }}>
       <h1>재미로 알아보는 오늘 나의 운세!</h1>
       <p style={{ marginTop: "1rem" }}>
         오늘 나의 하루가 어떨지 점수와 함께 알아보아요!
       </p>
       <p style={{ marginTop: "2rem" }}>📧 meganchoi2008@gmail.com</p>
       <p style={{ fontSize: "14px", color: "gray", marginTop: "2rem" }}>
         © 2025 Megan-Yoojung All rights reserved.
       </p>
     </div>
   );
 }
 
