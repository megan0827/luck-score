
export default function ResultsPage() {
   return (
     <div style={{ padding: "2rem", textAlign: "center" }}>
       <h1>운세 점수별 코멘트</h1>
       <div style={{ marginTop: "2rem", textAlign: "left", maxWidth: "600px", margin: "2rem auto" }}>
         <ul style={{ lineHeight: "2" }}>
           <li><strong>0 ~ 50점</strong>: 오늘은 조용히 보내는 게 좋겠어요!</li>
           <li><strong>51 ~ 80점</strong>: 평범하지만 좋은 하루가 될 거예요!</li>
           <li><strong>81 ~ 90점</strong>: 행운이 따를 수 있는 하루예요!</li>
           <li><strong>91 ~ 100점</strong>: 오늘은 최고의 날이에요!</li>
         </ul>
       </div>
     </div>
   );
 }
 
