"use client";

import { useState } from "react";
import Link from "next/link";

export default function CreatePage() {
  const [score, setScore] = useState(null);
  const [message, setMessage] = useState("");
  const [img, setImg] = useState("");

  const getFortune = () => {
    const randomScore = Math.floor(Math.random() * 101); // 0~100
    let msg = "";
    let image = "";

    if (randomScore <= 50) {
      msg = "오늘은 조용히 보내는 게 좋겠어요!";
      image = "/images/IMG_9736.JPG";
    } else if (randomScore <= 80) {
      msg = "평범하지만 좋은 하루가 될 거예요!";
      image = "/images/IMG_9737.JPG";
    } else if (randomScore <= 90) {
      msg = "행운이 따를 수 있는 하루예요!";
      image = "/images/IMG_9740.JPG";
    } else {
      msg = "오늘은 최고의 날이에요!";
      image = "/images/IMG_9735.JPG";
    }

    setScore(randomScore);
    setMessage(msg);
    setImg(image);
  };

  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h1>오늘 나의 운세 점수는...?</h1>
      <button onClick={getFortune} style={buttonStyle}>
        운세 확인하기
      </button>

      {score !== null && (
        <div style={{ marginTop: "2rem", textAlign: "center" }}>
          <h2>{score}점!</h2>
          <img
            src={img}
            alt="운세 이미지"
            style={{ width: "150px", marginTop: "1rem", display: "block", marginLeft: "auto", marginRight: "auto" }}
          />
          <p style={{ marginTop: "1rem" }}>{message}</p>
          <Link href="/">
            <button style={{ ...buttonStyle, marginTop: "1.5rem" }}>
              홈으로 돌아가기
            </button>
          </Link>
        </div>
      )}
    </div>
  );
}

const buttonStyle = {
  padding: "0.5rem 1rem",
  backgroundColor: "#4F46E5",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
};

