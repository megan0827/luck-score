import Image from "next/image";

export default function Home() {
  return (
    <h2>Section</h2>
  );
}
