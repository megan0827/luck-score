"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewNotePage() {

    const [title, setTitle] = useState("");
    const [content, setContent] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(title ,content);
    }

  return (
    <main className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">🆕 새 메모</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          className="w-full p-2 border rounded"
          placeholder="제목" onChange={(e) => setTitle(e.target.value)}
          
        />
        <textarea
          className="w-full p-2 border rounded"
          placeholder="내용" onChange={(e) => setContent(e.target.value)}
         
        />
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded"
          type="submit"
        >
          저장하기
        </button>
      </form>
    </main>
  );
}
