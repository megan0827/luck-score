const fs = require("fs");
const path = require("path");

const NOTES_FILE = path.join(process.cwd(), "data", "notes.json");

export default function handler(req, res) {

  if (req.method === "GET") {
  
  } else if (req.method === "DELETE") {
  
  } else {
  
  }
}