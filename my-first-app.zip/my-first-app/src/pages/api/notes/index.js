const fs = require('fs');
const path = require('path');

const NOTES_FILE = path.join(process.cwd(), 'data', 'notes.json');

export default function handler(req, res) {
  if (req.method === 'GET') {
    // 메모 목록 가져오기
    const data = fs.readFileSync(NOTES_FILE, "utf8")
    const notes = JSON.parse(data);
    res.status(200).json(notes);
  } else if (req.method === 'POST') {
    // 새 메모 추가
    const data = fs.readFileSync(NOTES_FILE, "utf8")
    const notes = JSON.parse(data);

    const newNote = {
        id: Date.now(),
        ...req.body,
    };
    notes.push(newNote);

    fs.writeFileSync(NOTES_FILE, JSON.stringify(notes));
    res.status(201).json(newNote);
  } else {
    res.status(404).end();
  }
}